import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/theme/app_design.dart';
import '../home_palette.dart';

/// ═══════════════════════════════════════════════════════════════════════════
/// Виджеты для главной: активный заказ, срочные заявки рядом, бонус дня.
/// ═══════════════════════════════════════════════════════════════════════════

/// Плашка активного заказа — «Мастер в пути».
class ActiveOrderBanner extends StatefulWidget {
  const ActiveOrderBanner({
    super.key,
    required this.p,
    this.masterName = 'Алишер Муродов',
    this.service = 'Ремонт проводки',
    this.onTap,
  });

  final HomePalette p;
  final String masterName;
  final String service;
  final VoidCallback? onTap;

  @override
  State<ActiveOrderBanner> createState() => _ActiveOrderBannerState();
}

class _ActiveOrderBannerState extends State<ActiveOrderBanner>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: AppDesign.navyGradient,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: AppDesign.navy.withValues(alpha: 0.3),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            // Pulsing map dot
            AnimatedBuilder(
              animation: _pulse,
              builder: (context, _) {
                return Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: AppDesign.brand.withValues(alpha: 0.15 + _pulse.value * 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: const BoxDecoration(
                        gradient: AppDesign.brandGradient,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(LucideIcons.navigation, color: Colors.white, size: 18),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppDesign.brand.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'В ПУТИ',
                          style: GoogleFonts.inter(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: AppDesign.brandLight,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '~15 мин',
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Colors.white.withValues(alpha: 0.8),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    widget.masterName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    widget.service,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: Colors.white.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(LucideIcons.map, color: Colors.white, size: 20),
            ),
          ],
        ),
      ),
    );
  }
}

/// Лента срочных заявок рядом — создаёт ощущение живого приложения.
class UrgentRequestsFeed extends StatefulWidget {
  const UrgentRequestsFeed({super.key, required this.p});

  final HomePalette p;

  @override
  State<UrgentRequestsFeed> createState() => _UrgentRequestsFeedState();
}

class _UrgentRequestsFeedState extends State<UrgentRequestsFeed> {
  int _index = 0;
  Timer? _timer;

  static const _requests = <({String text, String distance, String time, IconData icon, Color color})>[
    (text: 'Ищут электрика', distance: '2 км', time: '1 мин назад', icon: LucideIcons.zap, color: Color(0xFFF59E0B)),
    (text: 'Нужен сантехник', distance: '800 м', time: '3 мин назад', icon: LucideIcons.droplet, color: Color(0xFF3B82F6)),
    (text: 'Требуется маляр', distance: '1.5 км', time: '5 мин назад', icon: LucideIcons.paint_roller, color: Color(0xFF8B5CF6)),
    (text: 'Сборка мебели', distance: '3 км', time: '7 мин назад', icon: LucideIcons.armchair, color: Color(0xFF14B8A6)),
  ];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (mounted) setState(() => _index = (_index + 1) % _requests.length);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.p;
    final r = _requests[_index];
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: p.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: p.border),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              color: Color(0xFFEF4444),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'Сейчас рядом',
            style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w700, color: p.muted),
          ),
          const Spacer(),
          Expanded(
            flex: 5,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              transitionBuilder: (child, anim) => SlideTransition(
                position: Tween(begin: const Offset(0, 0.5), end: Offset.zero).animate(anim),
                child: FadeTransition(opacity: anim, child: child),
              ),
              child: Row(
                key: ValueKey(_index),
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Icon(r.icon, size: 15, color: r.color),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      r.text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w700, color: p.text),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '· ${r.distance}',
                    style: GoogleFonts.inter(fontSize: 12, color: p.muted),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Карточка «Бонус дня» — открывает колесо фортуны.
class DailyBonusCard extends StatefulWidget {
  const DailyBonusCard({super.key, required this.onTap});

  final VoidCallback onTap;

  @override
  State<DailyBonusCard> createState() => _DailyBonusCardState();
}

class _DailyBonusCardState extends State<DailyBonusCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _shake;

  @override
  void initState() {
    super.initState();
    _shake = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _loop();
  }

  void _loop() async {
    while (mounted) {
      await Future.delayed(const Duration(seconds: 4));
      if (!mounted) return;
      await _shake.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _shake.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: AppDesign.goldGradient,
          borderRadius: BorderRadius.circular(18),
          boxShadow: AppDesign.glowShadow(AppDesign.accentOrange),
        ),
        child: Row(
          children: [
            AnimatedBuilder(
              animation: _shake,
              builder: (context, child) {
                final wobble = _shake.value < 0.5
                    ? _shake.value * 2
                    : (1 - _shake.value) * 2;
                return Transform.rotate(
                  angle: wobble * 0.3 * (_shake.value * 10 % 2 < 1 ? 1 : -1),
                  child: child,
                );
              },
              child: Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.25),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(LucideIcons.gift, color: Colors.white, size: 26),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Бонус дня ждёт!',
                    style: GoogleFonts.inter(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Крути колесо и получи скидку',
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'Крутить',
                style: GoogleFonts.inter(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: AppDesign.accentOrange,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
